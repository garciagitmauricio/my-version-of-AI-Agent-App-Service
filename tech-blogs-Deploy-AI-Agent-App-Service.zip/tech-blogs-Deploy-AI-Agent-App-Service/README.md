1. git clone -b Deploy-AI-Agent-App-Service https://github.com/robrita/tech-blogs

2. copy sample.env to .env and update

3. python -m venv venv

4. .\venv\Scripts\activate

5. python -m pip install -r requirements.txt

6. chainlit run app.py
